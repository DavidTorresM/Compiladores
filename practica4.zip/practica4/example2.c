int main(){

	printf("hola como estas");

	return 0;
}
