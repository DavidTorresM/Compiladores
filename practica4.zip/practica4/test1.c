float x = 3.14f;
char a = '\n';
int y = (int) x;
y++;
y+=10;
int anio=1992;
int is21= anio>2000 ? 1 : 0 ; 
