int anio=1992;
int is21= anio>2000 ? 1 : 0 ; 
